-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2019 at 02:43 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dblaundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `dbcucian`
--

CREATE TABLE `dbcucian` (
  `Id` int(11) NOT NULL,
  `Kode` varchar(11) NOT NULL,
  `Namapelanggan` varchar(250) NOT NULL,
  `Jeniscucian` varchar(100) NOT NULL,
  `Jumlahkg` varchar(12) NOT NULL,
  `Jumlahcucian` varchar(12) NOT NULL,
  `Hargakg` varchar(12) NOT NULL,
  `Totalharga` varchar(12) NOT NULL,
  `Tglterima` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbcucian`
--

INSERT INTO `dbcucian` (`Id`, `Kode`, `Namapelanggan`, `Jeniscucian`, `Jumlahkg`, `Jumlahcucian`, `Hargakg`, `Totalharga`, `Tglterima`) VALUES
(31, 'p002', 'juanadi', 'biasa', '14', '50', '5000', '112000', '14-03-2019'),
(32, 'P001', 'niwayan', 'biasa', '13', '39', '5000', '65000', '19-04-2019'),
(33, 'P003', 'iwnfalse', 'Kasur', '23', '1', '10000', '230000', '09-04-2019'),
(35, 'rity', '.4tj.5gt', 'Paket Express', '6', '54', '8000', '48000', '30-04-2019'),
(36, 'p005', 'steve', 'Biasa', '4', '12', '5000', '20000', '23-09-2019');

-- --------------------------------------------------------

--
-- Table structure for table `dbjeniscucian`
--

CREATE TABLE `dbjeniscucian` (
  `Id` int(11) NOT NULL,
  `Kode` varchar(11) NOT NULL,
  `Jeniscucian` varchar(100) NOT NULL,
  `Hargakg` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbjeniscucian`
--

INSERT INTO `dbjeniscucian` (`Id`, `Kode`, `Jeniscucian`, `Hargakg`) VALUES
(1, 'JC001', 'Biasa', '5000'),
(3, 'JC003', 'Boneka', '8000'),
(4, 'JC004', 'Kasur', '90000'),
(5, 'JC002', 'Paket Express', '8000');

-- --------------------------------------------------------

--
-- Table structure for table `dbjenisstatus`
--

CREATE TABLE `dbjenisstatus` (
  `Id` int(11) NOT NULL,
  `Kode` varchar(11) NOT NULL,
  `Jenisstatus` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbjenisstatus`
--

INSERT INTO `dbjenisstatus` (`Id`, `Kode`, `Jenisstatus`) VALUES
(1, 'Js001', 'sedang dalam proses pengerjaan Pencuci'),
(2, 'Js002', 'Cucian Anda telah selesai'),
(3, ' js004', 'data coba'),
(4, 'r4otu', 'ini jeneis statuts baru');

-- --------------------------------------------------------

--
-- Table structure for table `dbkasir`
--

CREATE TABLE `dbkasir` (
  `Id` int(11) NOT NULL,
  `Kode` varchar(11) NOT NULL,
  `Jeniscucian` varchar(50) NOT NULL,
  `Namapelanggan` varchar(150) NOT NULL,
  `Tanggalpengambilan` varchar(50) NOT NULL,
  `Totalharga` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbkasir`
--

INSERT INTO `dbkasir` (`Id`, `Kode`, `Jeniscucian`, `Namapelanggan`, `Tanggalpengambilan`, `Totalharga`) VALUES
(9, 'P002', 'extra', 'jenus', '03-04-2019', '20000'),
(10, '3235', 'Express', 'r53tewt', '03-04-2019', '5322434'),
(11, 'p004', 'Biasa', 'juanda', '03-04-2019', '350000'),
(12, 'p001', 'Biasa', 'denus', '12-04-2019', '75000'),
(13, 'p033', 'Express', 'mardianato', '13-04-2019', '196000'),
(14, 'rity', 'Paket Express', '.4tj.5gt', '30-04-2019', '48000');

-- --------------------------------------------------------

--
-- Table structure for table `dbpengerjaan`
--

CREATE TABLE `dbpengerjaan` (
  `Id` int(11) NOT NULL,
  `Kode` varchar(11) NOT NULL,
  `Namapelanggan` varchar(250) NOT NULL,
  `Jeniscucian` varchar(100) NOT NULL,
  `Statuspengerjaan` varchar(100) NOT NULL,
  `Daritanggal` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbpengerjaan`
--

INSERT INTO `dbpengerjaan` (`Id`, `Kode`, `Namapelanggan`, `Jeniscucian`, `Statuspengerjaan`, `Daritanggal`) VALUES
(27, 'p0547', 'hukki', 'Express', 'Proses pencucian', '17-04-2019'),
(28, 'p002', 'juanadi', 'Boneka', 'Selesai', '17-04-2019'),
(29, 'rity', '.4tj.5gt', 'Paket Express', '', '30-04-2019'),
(30, 'P004', 'fryscila', 'Kasur', '', '03-06-2019');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$flohp3YRMzEcN00u5IEbl.0r8ZdhptvOJh16ZnPoao5OrJECtulte');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dbcucian`
--
ALTER TABLE `dbcucian`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Kode` (`Kode`);

--
-- Indexes for table `dbjeniscucian`
--
ALTER TABLE `dbjeniscucian`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dbjenisstatus`
--
ALTER TABLE `dbjenisstatus`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dbkasir`
--
ALTER TABLE `dbkasir`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Id` (`Id`),
  ADD UNIQUE KEY `Kodepem` (`Kode`),
  ADD UNIQUE KEY `Id_3` (`Id`),
  ADD KEY `Id_2` (`Id`);

--
-- Indexes for table `dbpengerjaan`
--
ALTER TABLE `dbpengerjaan`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Kode` (`Kode`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dbcucian`
--
ALTER TABLE `dbcucian`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `dbjeniscucian`
--
ALTER TABLE `dbjeniscucian`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dbjenisstatus`
--
ALTER TABLE `dbjenisstatus`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dbkasir`
--
ALTER TABLE `dbkasir`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `dbpengerjaan`
--
ALTER TABLE `dbpengerjaan`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
